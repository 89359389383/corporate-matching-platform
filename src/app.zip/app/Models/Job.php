<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Job extends Model
{
    use HasFactory;

    public const STATUS_DRAFT = 0;
    public const STATUS_PUBLISHED = 1;
    public const STATUS_STOPPED = 2;

    protected $fillable = [
        'company_id',
        'title',
        'description',
        'required_skills_text',
        'reward_type',
        'min_rate',
        'max_rate',
        'work_time_text',
        'status',
    ];

    protected $casts = [
        'min_rate' => 'integer',
        'max_rate' => 'integer',
        'status' => 'integer',
    ];

    /**
     * こ�E求人を投稿した企業惁E��を取征E     * 使用場面: 求人詳細画面で企業惁E��を表示する際など
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * こ�E求人への応募一覧を取征E     * 使用場面: 企業が応募老E��覧を確認する際など
     */
    public function applications(): HasMany
    {
        return $this->hasMany(Application::class);
    }

    /**
     * こ�E求人に関連するスカウト一覧を取征E     * 使用場面: 求人に関連するスカウト送信履歴を確認する際など
     */
    public function scouts(): HasMany
    {
        return $this->hasMany(Scout::class);
    }

    /**
     * こ�E求人に関連するメチE��ージスレチE��一覧を取征E     * 使用場面: 求人に関連するメチE��ージ履歴を表示する際など
     */
    public function threads(): HasMany
    {
        return $this->hasMany(Thread::class);
    }
}