<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FreelancerPortfolio extends Model
{
    use HasFactory;

    protected $fillable = [
        'freelancer_id',
        'url',
        'sort_order',
    ];

    protected $casts = [
        'sort_order' => 'integer',
    ];

    /**
     * こ�Eポ�Eトフォリオを所有するフリーランサー惁E��を取征E     * 使用場面: ポ�Eトフォリオ編雁E��にフリーランサー惁E��を参照する際など
     */
    public function freelancer(): BelongsTo
    {
        return $this->belongsTo(Freelancer::class);
    }
}