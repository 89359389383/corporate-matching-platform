<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Message extends Model
{
    use HasFactory;

    use SoftDeletes;

    protected $fillable = [
        'thread_id',
        'sender_type',
        'sender_id',
        'body',
        'sent_at',
    ];

    protected $casts = [
        'sender_id' => 'integer',
        'sent_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    /**
     * こ�EメチE��ージが属するスレチE��惁E��を取征E     * 使用場面: メチE��ージ一覧表示時にスレチE��惁E��を参照する際など
     */
    public function thread(): BelongsTo
    {
        return $this->belongsTo(Thread::class);
    }

    /**
     * メチE��ージ送信老E��企業の場合�E企業惁E��を取征E     * 使用場面: メチE��ージ表示時に送信老E��めE��イコンを表示する際など
     */
    public function senderCompany(): BelongsTo
    {
        return $this->belongsTo(Company::class, 'sender_id');
    }

    /**
     * メチE��ージ送信老E��フリーランサーの場合�Eフリーランサー惁E��を取征E     * 使用場面: メチE��ージ表示時に送信老E��めE��イコンを表示する際など
     */
    public function senderFreelancer(): BelongsTo
    {
        return $this->belongsTo(Freelancer::class, 'sender_id');
    }
}