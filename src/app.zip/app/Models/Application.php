<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Application extends Model
{
    use HasFactory;

    public const STATUS_PENDING = 0;
    public const STATUS_IN_PROGRESS = 1;
    public const STATUS_CLOSED = 2;

    protected $fillable = [
        'job_id',
        'freelancer_id',
        'message',
        'status',
    ];

    protected $casts = [
        'status' => 'integer',
    ];

    /**
     * 応募先�E求人惁E��を取征E     * 使用場面: 応募詳細画面で求人惁E��を表示する際など
     */
    public function job(): BelongsTo
    {
        return $this->belongsTo(Job::class);
    }

    /**
     * 応募したフリーランサー惁E��を取征E     * 使用場面: 企業が応募老E��覧を確認する際など
     */
    public function freelancer(): BelongsTo
    {
        return $this->belongsTo(Freelancer::class);
    }

    /**
     * こ�E応募に関連するスレチE���E�メチE��ージめE��取り�E�を取征E     * スキーマ丁Ethreads に application_id は無ぁE��め、E     * 「job_id + freelancer_id�E�E 実質 company は job に従属）」で導�Eします、E     * 使用場面: 応募後�EメチE��ージ履歴を表示する際など
     */
    public function thread(): HasOne
    {
        return $this->hasOne(Thread::class, 'job_id', 'job_id')
            ->where('freelancer_id', $this->freelancer_id);
    }
}