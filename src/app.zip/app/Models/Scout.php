<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Scout extends Model
{
    use HasFactory;

    public const STATUS_PENDING = 0;
    public const STATUS_IN_PROGRESS = 1;
    public const STATUS_CLOSED = 2;

    protected $fillable = [
        'company_id',
        'freelancer_id',
        'job_id',
        'message',
        'status',
    ];

    protected $casts = [
        'job_id' => 'integer',
        'status' => 'integer',
    ];

    /**
     * スカウトを送信した企業惁E��を取征E     * 使用場面: スカウト詳細画面で企業惁E��を表示する際など
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * スカウトを受信したフリーランサー惁E��を取征E     * 使用場面: 企業がスカウト送信履歴を確認する際など
     */
    public function freelancer(): BelongsTo
    {
        return $this->belongsTo(Freelancer::class);
    }

    /**
     * スカウトに関連する求人惁E��を取得（任意！E     * 使用場面: 特定�E求人に関連するスカウトかどぁE��を判定する際など
     */
    public function job(): BelongsTo
    {
        return $this->belongsTo(Job::class);
    }

    /**
     * こ�Eスカウトに関連するスレチE���E�メチE��ージめE��取り�E�を取征E     * スキーマ丁Ethreads に scout_id は無ぁE��め、E     * 「company_id + freelancer_id + job_id�E�Eullable�E�」で導�Eします、E     * 使用場面: スカウト後�EメチE��ージ履歴を表示する際など
     */
    public function thread(): HasOne
    {
        $relation = $this->hasOne(Thread::class, 'company_id', 'company_id')
            ->where('freelancer_id', $this->freelancer_id);

        if ($this->job_id === null) {
            return $relation->whereNull('job_id');
        }

        return $relation->where('job_id', $this->job_id);
    }
}