<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'overview',
        'contact_name',
        'department',
        'introduction',
    ];

    /**
     * 企業に紐づくユーザーアカウント情報を取征E     * 使用場面: ログイン認証めE��ーザー惁E��の取得時など
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * 企業が投稿した求人一覧を取征E     * 使用場面: 企業ダチE��ュボ�Eドで自社の求人一覧を表示する際など
     */
    public function jobs(): HasMany
    {
        return $this->hasMany(Job::class);
    }

    /**
     * 企業が送信したスカウト一覧を取征E     * 使用場面: スカウト送信履歴の確認や管琁E��面での表示など
     */
    public function scouts(): HasMany
    {
        return $this->hasMany(Scout::class);
    }

    /**
     * 企業が参加してぁE��メチE��ージスレチE��一覧を取征E     * 使用場面: メチE��ージ一覧画面で企業のスレチE��を表示する際など
     */
    public function threads(): HasMany
    {
        return $this->hasMany(Thread::class);
    }
}