<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Relations\HasOne;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'email',
        'password',
        'role',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * ユーザーが企業アカウント�E場合�E企業惁E��を取征E     * 使用場面: ログイン後�Eユーザータイプ判定や企業惁E��の取得時など
     */
    public function company(): HasOne
    {
        return $this->hasOne(Company::class);
    }

    /**
     * ユーザーがフリーランサーアカウント�E場合�Eフリーランサー惁E��を取征E     * 使用場面: ログイン後�Eユーザータイプ判定やフリーランサー惁E��の取得時など
     */
    public function freelancer(): HasOne
    {
        return $this->hasOne(Freelancer::class);
    }
}