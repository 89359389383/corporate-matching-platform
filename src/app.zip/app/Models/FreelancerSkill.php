<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\Pivot;

class FreelancerSkill extends Pivot
{
    use HasFactory;

    protected $table = 'freelancer_skill';

    /**
     * ピ�EチE��ですが、このチE�Eブルは id を持つため incrementing を有効化します、E     */
    public $incrementing = true;

    protected $fillable = [
        'freelancer_id',
        'skill_id',
    ];

    /**
     * こ�Eスキル紐付けを所有するフリーランサー惁E��を取征E     * 使用場面: スキル紐付けの管琁E��検索時�E参�Eなど
     */
    public function freelancer(): BelongsTo
    {
        return $this->belongsTo(Freelancer::class);
    }

    /**
     * こ�E紐付けに関連するスキルマスタ惁E��を取征E     * 使用場面: スキル名�E表示めE��キル検索時�E参�Eなど
     */
    public function skill(): BelongsTo
    {
        return $this->belongsTo(Skill::class);
    }
}