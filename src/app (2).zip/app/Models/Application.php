<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Application extends Model
{
    use HasFactory;

    public const STATUS_PENDING = 0;
    public const STATUS_IN_PROGRESS = 1;
    public const STATUS_CLOSED = 2;

    protected $fillable = [
        'job_id',
        'corporate_id',
        'message',
        'desired_hourly_rate',
        'work_days',
        'work_time_from',
        'work_time_to',
        'note',
        'weekly_hours',
        'available_start',
        'status',
    ];

    protected $casts = [
        'status' => 'integer',
        'work_days' => 'array',
        'desired_hourly_rate' => 'integer',
        'weekly_hours' => 'integer',
    ];

    /**
     * ????E???E?????E     * ????: ??????????E??????????
     */
    public function job(): BelongsTo
    {
        return $this->belongsTo(Job::class);
    }

    /**
     * ????????????E?????E     * ????: ??????E???????????
     */
    public function corporate(): BelongsTo
    {
        return $this->belongsTo(Corporate::class);
    }

    /**
     * ??E??????????E???E???E?????E?????E????E     * ?????Ethreads ? application_id ???E????E     * ?job_id + freelancer_id?E?E ?? company ? job ????????E????E     * ????: ????E??E??????????????
     */
    public function thread(): HasOne
    {
        return $this->hasOne(Thread::class, 'job_id', 'job_id')
            ->where('corporate_id', $this->corporate_id);
    }
}