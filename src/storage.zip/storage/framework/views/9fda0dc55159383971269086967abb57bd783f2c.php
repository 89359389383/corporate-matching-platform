<style>
    /* Corporate common styles: header / nav / panels / buttons */
    :root {
        --header-bg: #ffffff;
        --border: #e1e4e8;
        --muted: #6a737d;
        --primary: #0366d6;
        --surface: #ffffff;
    }
    .header { background: var(--header-bg); border-bottom: 1px solid var(--border); padding: 0.8rem 1rem; position: sticky; top: 0; z-index: 100; }
    .header .logo-text { font-weight: 900; font-size: 20px; color: #111827; }
    .nav-links { display:flex; gap:1rem; align-items:center; }
    .nav-link { text-decoration:none; color:var(--muted); font-weight:700; padding:0.4rem 0.8rem; border-radius:8px; }
    .nav-link.active { background: var(--primary); color:#fff; }
    .badge { background:#d73a49; color:#fff; padding:0.15rem 0.45rem; border-radius:999px; font-weight:800; font-size:0.75rem; }
    .main-content { max-width: 1200px; margin: 0 auto; padding: 1.5rem; }
    .panel { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 1rem; box-shadow: 0 1px 2px rgba(0,0,0,0.04); }
    .page-title { font-size: 1.8rem; font-weight:900; margin-bottom:0.5rem; }
    .page-subtitle { color: var(--muted); margin-bottom:1rem; font-weight:700; }
    .btn { display:inline-flex; padding:0.6rem 0.9rem; border-radius:10px; font-weight:900; border:1px solid var(--border); background:#fff; color:#111827; text-decoration:none; cursor:pointer; }
    .btn.primary { background: var(--primary); color:#fff; border-color:var(--primary); }
    .card { background:#fff; border:1px solid var(--border); border-radius:12px; padding:1rem; margin-bottom:0.75rem; }
    .muted { color:var(--muted); font-weight:700; }
    /* chat specific */
    .chat-pane { display:flex; flex-direction:column; min-height:400px; }
    .chat-header { padding:0.75rem 1rem; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; }
    .messages { padding:1rem; overflow-y:auto; }
    .bubble { padding:0.9rem 1rem; border-radius:14px; border:1px solid var(--border); background:#fff; margin-bottom:0.6rem; }
</style>
<?php /**PATH /var/www/resources/views/partials/corporate-style.blade.php ENDPATH**/ ?>