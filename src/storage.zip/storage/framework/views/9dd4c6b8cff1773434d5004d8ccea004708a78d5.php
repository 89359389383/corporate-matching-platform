
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>法人一覧（企業）- AITECH</title>
    <?php echo $__env->make('partials.company-header-style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        :root {
            --header-height: 72px;           /* md 基本高さ */
            --header-height-mobile: 72px;     /* xs / mobile */
            --header-height-sm: 72px;         /* sm */
            --header-height-md: 72px;        /* md */
            --header-height-lg: 72px;        /* lg */
            --header-height-xl: 72px;        /* xl */
            --header-height-current: var(--header-height-mobile);
            --header-padding-x: 1rem;
        }

        /* Breakpoint: sm (>=640px) */
        @media (min-width: 640px) {
            :root {
                --header-padding-x: 1.5rem;
                --header-height-current: var(--header-height-sm);
            }
        }

        /* Breakpoint: md (>=768px) -- デスクトップの基本 */
        @media (min-width: 768px) {
            :root {
                --header-padding-x: 2rem;
                --header-height-current: var(--header-height-md);
            }
        }

        /* Breakpoint: lg (>=1024px) */
        @media (min-width: 1024px) {
            :root {
                --header-padding-x: 2.5rem;
                --header-height-current: var(--header-height-lg);
            }
        }

        /* Breakpoint: xl (>=1280px) */
        @media (min-width: 1280px) {
            :root {
                --header-padding-x: 3rem;
                --header-height-current: var(--header-height-xl);
            }
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { font-size: 97.5%; }
        body {
            font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background-color: #fafbfc;
            color: #24292e;
            line-height: 1.5;
        }

        /* Header (4 breakpoints: sm/md/lg/xl) */
        .header {
            background-color: #ffffff;
            border-bottom: 1px solid #e1e4e8;
            padding: 0 var(--header-padding-x);
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            min-height: var(--header-height-current);
        }
        .header-content {
            max-width: 1600px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr auto; /* mobile: ロゴ / 右側 */
            align-items: center;
            gap: 0.5rem;
            height: var(--header-height-current);
            position: relative;
            min-width: 0;
            padding: 0.25rem 0; /* 縦余白を確保 */
        }

        /* md以上: ロゴ / 中央ナビ / 右側 (ユーザー) */
        @media (min-width: 768px) {
            .header-content { grid-template-columns: auto 1fr auto; gap: 1rem; }
        }

        /* lg: より広く間隔を取る */
        @media (min-width: 1024px) {
            .header-content { gap: 1.5rem; padding: 0.5rem 0; }
        }

        .header-left { display: flex; align-items: center; gap: 0.75rem; min-width: 0; }
        .header-right { display: flex; align-items: center; justify-content: flex-end; min-width: 0; gap: 0.75rem; }

        /* ロゴ（左） */
        .logo { display: flex; align-items: center; gap: 8px; min-width: 0; }
        .logo-text {
            font-weight: 900;
            font-size: 18px;
            margin-left: 0;
            color: #111827;
            letter-spacing: 1px;
            white-space: nowrap;
        }
        @media (min-width: 640px) { .logo-text { font-size: 20px; } }
        @media (min-width: 768px) { .logo-text { font-size: 22px; } }
        @media (min-width: 1024px) { .logo-text { font-size: 24px; } }
        @media (min-width: 1280px) { .logo-text { font-size: 26px; } }
        .logo-badge {
            background: #0366d6;
            color: #fff;
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        /* Mobile nav toggle */
        .nav-toggle {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: 1px solid #e1e4e8;
            background: #fff;
            cursor: pointer;
            transition: all 0.15s ease;
            flex: 0 0 auto;
        }
        .nav-toggle:hover { background: #f6f8fa; }
        .nav-toggle:focus-visible { outline: none; box-shadow: 0 0 0 3px rgba(3, 102, 214, 0.15); }
        .nav-toggle svg { width: 22px; height: 22px; color: #24292e; }
        @media (min-width: 768px) { .nav-toggle { display: none; } }

        .nav-links {
            display: none; /* mobile: hidden (use hamburger) */
            align-items: center;
            justify-content: center;
            flex-wrap: nowrap;
            min-width: 0;
            overflow: hidden;
            gap: 1.25rem;
        }
        @media (min-width: 640px) { .nav-links { display: none; } } /* smではまだ省スペースにすることが多い */
        @media (min-width: 768px) { .nav-links { display: flex; gap: 1.25rem; } }
        @media (min-width: 1024px) { .nav-links { gap: 2rem; } }
        @media (min-width: 1280px) { .nav-links { gap: 3rem; } }

        .nav-link {
            text-decoration: none;
            color: #586069;
            font-weight: 500;
            font-size: 1.05rem;
            padding: 0.6rem 1rem;
            border-radius: 8px;
            transition: all 0.15s ease;
            position: relative;
            letter-spacing: -0.01em;
            display: inline-flex;
            align-items: center;
            white-space: nowrap;
        }
        @media (min-width: 768px) { .nav-link { font-size: 1.1rem; padding: 0.75rem 1.25rem; } }
        @media (min-width: 1280px) { .nav-link { font-size: 1.15rem; } }
        .nav-link.has-badge { padding-right: 3rem; }
        .nav-link:hover { background-color: #f6f8fa; color: #24292e; }
        .nav-link.active {
            background-color: #0366d6;
            color: white;
            box-shadow: 0 2px 8px rgba(3, 102, 214, 0.3);
        }
        .badge {
            background-color: #d73a49;
            color: white;
            border-radius: 50%;
            padding: 0.15rem 0.45rem;
            font-size: 0.7rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 1px 3px rgba(209, 58, 73, 0.3);
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
        }
        .user-menu { display: flex; align-items: center; position: static; transform: none; }

        /* Mobile nav menu */
        .mobile-nav {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: #fff;
            border-bottom: 1px solid #e1e4e8;
            box-shadow: 0 16px 40px rgba(0,0,0,0.10);
            padding: 0.75rem var(--header-padding-x);
            display: none;
            z-index: 110;
        }
        .header.is-mobile-nav-open .mobile-nav { display: block; }
        @media (min-width: 768px) { .mobile-nav { display: none !important; } }
        .mobile-nav-inner {
            max-width: 1600px;
            margin: 0 auto;
            display: grid;
            gap: 0.5rem;
        }
        .mobile-nav .nav-link {
            width: 100%;
            justify-content: flex-start;
            background: #fafbfc;
            border: 1px solid #e1e4e8;
            padding: 0.875rem 1rem;
        }
        .mobile-nav .nav-link:hover { background: #f6f8fa; }
        .mobile-nav .nav-link.active {
            background-color: #0366d6;
            color: #fff;
            border-color: #0366d6;
        }
        .mobile-nav .nav-link.has-badge { padding-right: 1rem; }
        .mobile-nav .badge {
            position: static;
            transform: none;
            margin-left: auto;
            margin-right: 0;
        }
        .user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: none;
            padding: 0;
            appearance: none;
            flex: 0 0 auto;
        }
        /* avatar size responsive */
        @media (min-width: 640px) { .user-avatar { width: 40px; height: 40px; } }
        @media (min-width: 768px) { .user-avatar { width: 44px; height: 44px; } }
        @media (min-width: 1024px) { .user-avatar { width: 48px; height: 48px; } }
        @media (min-width: 1280px) { .user-avatar { width: 52px; height: 52px; } }
        .user-avatar:hover { transform: scale(1.08); box-shadow: 0 4px 16px rgba(0,0,0,0.2); }
        .user-avatar:focus-visible { outline: none; box-shadow: 0 0 0 3px rgba(3, 102, 214, 0.25), 0 2px 8px rgba(0,0,0,0.1); }

        /* Dropdown */
        .dropdown { position: relative; }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background-color: white;
            min-width: 240px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08);
            border-radius: 12px;
            z-index: 1000;
            border: 1px solid #e1e4e8;
            margin-top: 0.5rem;
        }
        .dropdown.is-open .dropdown-content { display: block; }
        .dropdown-item {
            display: block;
            padding: 0.875rem 1.25rem;
            text-decoration: none;
            color: #586069;
            transition: all 0.15s ease;
            border-radius: 6px;
            margin: 0.25rem;
            white-space: nowrap;
        }
        .dropdown-item:hover { background-color: #f6f8fa; color: #24292e; }
        .dropdown-divider { height: 1px; background-color: #e1e4e8; margin: 0.5rem 0; }

        /* Layout */
        .main-content {
            display: flex;
            flex-direction: column;
            max-width: 1600px;
            margin: 0 auto;
            padding: 1.25rem;
            gap: 1.25rem;
        }
        @media (min-width: 768px) {
            .main-content { padding: 1.5rem; gap: 1.5rem; }
        }

        /*
          1200px以下: 1024px以下と同様に「検索 → 一覧 → 選択中」を1列表示にする
          1201px以上: 3列（検索 / 一覧 / 選択中）を横並び + サイドバー追従
        */
        @media (min-width: 1201px) {
            .main-content {
                flex-direction: row;
                padding: 3rem;
                gap: 3rem;
                align-items: flex-start;
            }
        }

        .sidebar {
            width: 100%;
            flex-shrink: 0;
            /* 1200px以下は通常フロー（固定/追従しない） */
            position: static;
            top: auto;
            align-self: auto;
            z-index: 50;
        }
        @media (min-width: 1201px) {
            .sidebar:not(.right) {
                width: 320px;
                position: sticky;
                top: calc(var(--header-height-current) + 1.5rem);
                align-self: flex-start;
            }
            .sidebar.right {
                width: 380px;
                position: sticky;
                top: calc(var(--header-height-current) + 1.5rem);
                align-self: flex-start;
            }
        }
        .content-area {
            flex: 1;
            min-width: 0;
            margin-left: 0;
            margin-right: 0;
        }

        /* Panels / Inputs */
        .panel {
            background-color: white;
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
            border: 1px solid #e1e4e8;
            margin-bottom: 2rem;
            min-width: 0;
            overflow: hidden;
        }
        .panel h3 {
            font-size: 0.95rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #24292e;
            letter-spacing: -0.01em;
        }
        .field { margin-bottom: 1.25rem; }
        .field label {
            display: block;
            font-weight: 700;
            margin-bottom: 0.75rem;
            color: #586069;
            font-size: 0.9rem;
        }
        .input, .textarea, .select {
            width: 100%;
            padding: 0.875rem 1rem;
            border: 2px solid #e1e4e8;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.15s ease;
            background-color: #fafbfc;
        }
        .textarea { min-height: 140px; resize: vertical; }
        .input:focus, .textarea:focus, .select:focus {
            outline: none;
            border-color: #0366d6;
            box-shadow: 0 0 0 3px rgba(3, 102, 214, 0.1);
            background-color: white;
        }
        .btn {
            padding: 0.875rem 1.75rem;
            border-radius: 8px;
            font-weight: 700;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s ease;
            cursor: pointer;
            border: none;
            font-size: 0.95rem;
            letter-spacing: -0.01em;
            white-space: nowrap;
        }
        .btn-primary { background-color: #0366d6; color: white; }
        .btn-primary:hover { background-color: #0256cc; transform: translateY(-1px); box-shadow: 0 4px 16px rgba(3, 102, 214, 0.3); }
        .search-btn {
            width: 100%;
            background-color: #0366d6;
            color: white;
            border: none;
            padding: 0.875rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
            font-size: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }
        .search-btn:hover {
            background-color: #0256cc;
            box-shadow: 0 2px 8px rgba(3, 102, 214, 0.3);
        }
        .clear-btn {
            background-color: #6a737d; /* gray */
            margin-top: 0.75rem;
        }
        .clear-btn:hover {
            background-color: #586069;
            box-shadow: 0 2px 8px rgba(106, 115, 125, 0.25);
        }
        .btn-secondary { background-color: #586069; color: white; }
        .btn-secondary:hover { background-color: #4c5561; transform: translateY(-1px); }

        /* Search: rate range inputs (万円) */
        .input-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            min-width: 0;
        }
        .input-group .input {
            flex: 1 1 0;
            min-width: 0;
        }
        .unit {
            font-weight: 800;
            color: #6a737d;
            white-space: nowrap;
            flex: 0 0 auto;
            padding-left: 0.25rem;
        }
        .range-sep {
            font-weight: 900;
            color: #6a737d;
            white-space: nowrap;
            flex: 0 0 auto;
        }

        /* Cards */
        .page-title {
            font-size: 1.6rem;
            font-weight: 800;
            margin-bottom: 2rem;
            color: #24292e;
            letter-spacing: -0.025em;
        }
        .list { display: grid; gap: 1.5rem; }
        .card {
            background-color: white;
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
            transition: all 0.2s ease;
            border: 1px solid #e1e4e8;
            position: relative;
            overflow: hidden;
            cursor: pointer;
            min-width: 0;
        }
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        }
        .card:hover { transform: translateY(-3px); box-shadow: 0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08); }
        .card.is-selected { outline: 3px solid rgba(3, 102, 214, 0.2); border-color: rgba(3,102,214,0.35); }
        .card-header {
            position: absolute;
            top: 0.75rem;
            right: 0.75rem;
            display: flex;
            gap: 0.5rem;
            z-index: 5;
        }
        .card-scout-btn {
            padding: 0.45rem 0.65rem;
            margin-top: 8px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.85rem;
            text-decoration: none;
            transition: all 0.12s ease;
            white-space: nowrap;
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .row { display: flex; gap: 1rem; align-items: flex-start; min-width: 0; }
        .avatar {
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 800;
            flex: 0 0 auto;
            box-shadow: 0 2px 10px rgba(0,0,0,0.12);
        }
        .name { font-size: 1.1rem; font-weight: 800; line-height: 1.2; margin-bottom: 0.25rem; word-wrap: break-word; overflow-wrap: break-word; }
        .sub { color: #586069; font-weight: 600; font-size: 0.85rem; word-wrap: break-word; overflow-wrap: break-word; }
        .desc { color: #586069; margin-top: 0.75rem; line-height: 1.6; word-wrap: break-word; overflow-wrap: break-word; }
        .tags { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.85rem; }
        .tag { background-color: #f1f8ff; color: #0366d6; padding: 0.3rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: 700; border: 1px solid #c8e1ff; }
        .meta {
            display: grid;
            grid-template-columns: 1fr;
            gap: 0.75rem;
            margin-top: 1rem;
        }
        /* 追加した法人情報4項目は1行1項目で見せる */
        #dCorporateInfo,
        #dMeta {
            grid-template-columns: 1fr;
        }
        @media (min-width: 768px) {
            #dCorporateInfo {
                grid-template-columns: 1fr;
            }
            #dMeta {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        .meta-item {
            padding: 0.85rem;
            background-color: #f6f8fa;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            gap: 0.75rem;
            align-items: center;
            min-width: 0;
            overflow: hidden;
        }
        .meta-label { font-size: 15px; color: #6a737d; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; white-space: nowrap; flex-shrink: 0; }
        .meta-value {
            font-weight: 800;
            color: #24292e;
            min-width: 0;
            text-align: right;
            /* 複数行を許容して稼働情報などを切らさない */
            white-space: normal;
            overflow: visible;
        }

        /* Right detail */
        #detailPanel {
            /* パネル内でスクロール可能にする */
            max-height: calc(100vh - var(--header-height-current) - 3rem);
            overflow-y: auto;
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
        }
        /* 1200px以下では「カード直下に全幅表示」なので、パネル内スクロールは不要 */
        @media (max-width: 1200px) {
            #detailPanel { max-height: none; overflow: visible; }
            #detailSidebar { display: none; } /* 右サイドバーは非表示（中身はJSでカード直下へ移動） */
        }
        #detailPanel h3 {
            /* タイトルは固定 */
            flex-shrink: 0;
        }
        #detailContent {
            /* コンテンツ部分がスクロール可能 */
            flex: 1;
            min-height: 0;
        }
        #detailEmpty {
            /* 空の状態も固定 */
            flex-shrink: 0;
        }
        /* スクロールバーのスタイリング */
        #detailPanel::-webkit-scrollbar {
            width: 8px;
        }
        #detailPanel::-webkit-scrollbar-track {
            background: #f6f8fa;
            border-radius: 4px;
        }
        #detailPanel::-webkit-scrollbar-thumb {
            background: #c6cbd1;
            border-radius: 4px;
        }
        #detailPanel::-webkit-scrollbar-thumb:hover {
            background: #959da5;
        }
        .detail-title { font-size: 0.95rem; font-weight: 800; margin-top: 0.75rem; margin-bottom: 0.5rem; }
        .detail-actions { display: flex; gap: 0.75rem; margin-top: 1.25rem; flex-wrap: wrap; }
        .link { color: #0366d6; text-decoration: none; font-weight: 800; word-break: break-all; overflow-wrap: break-word; display: block; }
        .link:hover { text-decoration: underline; }

    </style>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <?php echo $__env->make('partials.company-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main-content">
        <aside class="sidebar">
            <div class="panel">
                <h3>検索条件</h3>
                <form method="GET" action="<?php echo e(route('company.corporates.index')); ?>">
                    <div class="field">
                        <label for="keyword">フリーワード</label>
                        <input id="keyword" name="keyword" class="input" type="text" placeholder="名前 / 職種 / スキル" value="<?php echo e(old('keyword', $keyword ?? '')); ?>">
                    </div>
                    <div class="field">
                        <label for="rate_min">希望単価</label>
                        <div class="input-group" aria-label="希望単価（下限〜上限）">
                            <div class="input-group" style="flex: 1 1 0;">
                                <input
                                    id="rate_min"
                                    name="rate_min"
                                    class="input"
                                    type="number"
                                    inputmode="numeric"
                                    min="0"
                                    step="1"
                                    placeholder="下限"
                                    value="<?php echo e(old('rate_min', $rateMin ?? '')); ?>"
                                >
                                <span class="unit">万</span>
                            </div>
                            <span class="range-sep">〜</span>
                            <div class="input-group" style="flex: 1 1 0;">
                                <input
                                    id="rate_max"
                                    name="rate_max"
                                    class="input"
                                    type="number"
                                    inputmode="numeric"
                                    min="0"
                                    step="1"
                                    placeholder="上限"
                                    value="<?php echo e(old('rate_max', $rateMax ?? '')); ?>"
                                >
                                <span class="unit">万</span>
                            </div>
                        </div>
                    </div>
                    <button class="search-btn" type="submit">検索</button>
                    <button class="search-btn clear-btn" type="button" onclick="window.location='<?php echo e(route('company.corporates.index')); ?>'">クリア</button>
                </form>
            </div>
        </aside>

        <section class="content-area flex-1 min-w-0">
            <h1 class="page-title text-2xl md:text-3xl font-black tracking-tight">法人一覧</h1>
            <div class="list grid grid-cols-1 gap-5" id="corporateList" aria-label="法人一覧">
                <?php $__empty_1 = true; $__currentLoopData = $corporates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $corporate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $avatarText = mb_substr($corporate->display_name, 0, 1);
                        $allSkills = $corporate->skills->pluck('name')->merge($corporate->customSkills->pluck('name'));
                        $workHours = $corporate->min_hours_per_week . '〜' . $corporate->max_hours_per_week . 'h';
                        $dailyText = null;
                        if (isset($corporate->hours_per_day) || isset($corporate->days_per_week)) {
                            $dailyParts = [];
                            if (isset($corporate->hours_per_day)) { $dailyParts[] = $corporate->hours_per_day . 'h/day'; }
                            if (isset($corporate->days_per_week)) { $dailyParts[] = $corporate->days_per_week . 'day/week'; }
                            $dailyText = implode('・', $dailyParts);
                        }
                        $workStyleText = '週' . $workHours . ($dailyText ? ' ' . $dailyText : '');
                        $minRate = $corporate->min_rate ?: null; // 0は未設定扱い
                        $maxRate = $corporate->max_rate ?: null; // 0は未設定扱い
                        if ($minRate !== null && $maxRate !== null) {
                            $rateText = $minRate . '〜' . $maxRate . '万';
                        } elseif ($minRate !== null || $maxRate !== null) {
                            $rateText = ($minRate ?? $maxRate) . '万';
                        } else {
                            $rateText = '未設定';
                        }
                    ?>
                    <?php
                        $currentThreadId = $scoutThreadMap[$corporate->id] ?? null;
                    ?>
                    <article class="card <?php echo e($index === 0 ? 'is-selected' : ''); ?> rounded-2xl bg-white border border-slate-200 shadow-sm p-5 md:p-6 relative overflow-hidden" tabindex="0" role="button" data-id="<?php echo e($corporate->id); ?>" aria-pressed="<?php echo e($index === 0 ? 'true' : 'false'); ?>">
                        <div class="card-header">
                            <?php if($currentThreadId): ?>
                                <a class="card-scout-btn btn-secondary" href="<?php echo e(route('company.threads.show', ['thread' => $currentThreadId])); ?>" aria-label="スカウト済み">スカウト済み</a>
                            <?php else: ?>
                                <a class="card-scout-btn btn-primary" href="<?php echo e(route('company.scouts.create', ['corporate_id' => $corporate->id])); ?>" aria-label="スカウト">スカウト</a>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="avatar" aria-hidden="true"><?php echo e($avatarText); ?></div>
                            <div style="min-width:0; flex: 1; overflow: hidden;">
                                <div class="name"><?php echo e($corporate->display_name); ?></div>
                                <div class="sub"><?php echo e($corporate->job_title ?? ''); ?></div>
                                <?php if($allSkills->isNotEmpty()): ?>
                                    <div class="tags" aria-label="スキル">
                                        <?php $__currentLoopData = $allSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="tag"><?php echo e($skill); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="meta" aria-label="ワークスタイル">
                            <div class="meta-item">
                                <div class="meta-label">希望単価</div>
                                <div class="meta-value" title="<?php echo e($rateText); ?>"><?php echo e($rateText); ?></div>
                            </div>
                            <div class="meta-item">
                                <div class="meta-label">稼働</div>
                                <div class="meta-value" title="<?php echo e($workStyleText); ?>">
                                    <?php echo e('週' . $workHours); ?>

                                    <?php if($dailyText): ?>
                                        <br><span><?php echo e($dailyText); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="rounded-2xl bg-white border border-slate-200 shadow-sm p-8 md:p-10 text-center text-slate-600">
                        <p class="text-base md:text-lg font-semibold">法人が見つかりませんでした。</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php if($corporates->hasPages()): ?>
                <div class="mt-8 flex justify-center">
                    <?php echo e($corporates->links()); ?>

                </div>
            <?php endif; ?>
        </section>

        <aside class="sidebar right" id="detailSidebar">
            <div id="detailSidebarHost">
                <div class="panel" id="detailPanel" aria-live="polite">
                    <h3>選択中の法人</h3>
                    <div id="detailContent" style="display: none;">
                        <div class="row">
                            <div class="avatar" id="dAvatar" aria-hidden="true"></div>
                            <div style="min-width:0; flex: 1; overflow: hidden;">
                                <div class="name" id="dName"></div>
                                <div class="sub" id="dRole"></div>
                            </div>
                        </div>

                        <div class="detail-title">自己紹介</div>
                        <div class="desc" id="dBio"></div>

                        <div class="detail-title">法人情報</div>
                        <div class="meta" id="dCorporateInfo"></div>

                        <div class="detail-title">スキル</div>
                        <div class="tags" id="dSkills"></div>

                        <div class="meta" id="dMeta"></div>

                        <div class="detail-title">ポートフォリオ</div>
                        <div class="desc" id="dPortfolio" style="word-break: break-all; overflow-wrap: break-word;"></div>

                        <div class="detail-title">経験企業</div>
                        <div class="desc" id="dExperienceCompanies"></div>

                        <div class="detail-actions">
                            <?php
                                $firstCorporate = $corporates->first();
                                $firstThreadId = $firstCorporate ? ($scoutThreadMap[$firstCorporate->id] ?? null) : null;
                            ?>
                            <?php if($firstThreadId): ?>
                                <a class="btn btn-secondary" id="dScoutLink" href="<?php echo e(route('company.threads.show', ['thread' => $firstThreadId])); ?>">スカウト済み</a>
                            <?php else: ?>
                                <a class="btn btn-primary" id="dScoutLink" href="<?php echo e($firstCorporate ? route('company.scouts.create') . '?corporate_id=' . $firstCorporate->id : '#'); ?>">スカウト</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div id="detailEmpty" style="text-align: center; padding: 2rem; color: #586069;">
                        <p>法人を選択してください</p>
                    </div>
                </div>
            </div>
        </aside>
    </main>

    <script>
        (function () {
            const dropdown = document.getElementById('userDropdown');
            const toggle = document.getElementById('userDropdownToggle');
            const menu = document.getElementById('userDropdownMenu');
            if (!dropdown || !toggle || !menu) return;

            const open = () => { dropdown.classList.add('is-open'); toggle.setAttribute('aria-expanded', 'true'); };
            const close = () => { dropdown.classList.remove('is-open'); toggle.setAttribute('aria-expanded', 'false'); };
            const isOpen = () => dropdown.classList.contains('is-open');

            toggle.addEventListener('click', (e) => { e.stopPropagation(); isOpen() ? close() : open(); });
            document.addEventListener('click', (e) => { if (!dropdown.contains(e.target)) close(); });
            document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
        })();
    </script>

    <script type="application/json" id="corporateDataJson"><?php echo json_encode(($corporateDataArray ?? []), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?></script>
    <script>
        (function () {
            const dataEl = document.getElementById('corporateDataJson');
            const corporateData = dataEl ? JSON.parse(dataEl.textContent || '[]') : [];

            const list = document.getElementById('corporateList');
            const detailPanel = document.getElementById('detailPanel');
            const detailSidebarHost = document.getElementById('detailSidebarHost');
            const detailContent = document.getElementById('detailContent');
            const detailEmpty = document.getElementById('detailEmpty');
            const dAvatar = document.getElementById('dAvatar');
            const dName = document.getElementById('dName');
            const dRole = document.getElementById('dRole');
            const dBio = document.getElementById('dBio');
            const dCorporateInfo = document.getElementById('dCorporateInfo');
            const dSkills = document.getElementById('dSkills');
            const dMeta = document.getElementById('dMeta');
            const dPortfolio = document.getElementById('dPortfolio');
            const dExperienceCompanies = document.getElementById('dExperienceCompanies');
            const dScoutLink = document.getElementById('dScoutLink');
            
            if (!list || !detailPanel || !detailContent || !detailEmpty || !dAvatar || !dName || !dRole || !dBio || !dCorporateInfo || !dSkills || !dMeta || !dPortfolio || !dExperienceCompanies || !dScoutLink) return;

            // データをIDでマッピング
            const dataMap = {};
            corporateData.forEach(item => {
                dataMap[item.id] = item;
            });

            const render = (id) => {
                const x = dataMap[id];
                if (!x) {
                    detailContent.style.display = 'none';
                    detailEmpty.style.display = 'block';
                    return;
                }
                
                detailContent.style.display = 'block';
                detailEmpty.style.display = 'none';
                
                dAvatar.textContent = x.avatar;
                dName.textContent = x.name;
                dRole.textContent = x.role;
                dBio.textContent = x.bio || '（未設定）';

                // 法人情報（受注者タイプ / 法人名 / 担当者名 / 会社サイトURL）
                dCorporateInfo.innerHTML = '';
                const addInfoRow = (label, valueNode) => {
                    const item = document.createElement('div');
                    item.className = 'meta-item';

                    const l = document.createElement('div');
                    l.className = 'meta-label';
                    l.textContent = label;

                    const v = document.createElement('div');
                    v.className = 'meta-value';
                    if (valueNode instanceof Node) v.appendChild(valueNode);
                    else v.textContent = valueNode;

                    item.appendChild(l);
                    item.appendChild(v);
                    dCorporateInfo.appendChild(item);
                };

                const recipientText = (x.recipientType === 'corporation') ? '法人' : '個人';
                addInfoRow('受注者タイプ', recipientText);

                const corpNameText = (x.recipientType === 'corporation')
                    ? ((x.corporationName && String(x.corporationName).trim()) ? String(x.corporationName) : '（未設定）')
                    : '（個人のため不要）';
                addInfoRow('法人名', corpNameText);

                const corpContactText = (x.recipientType === 'corporation')
                    ? ((x.corporationContactName && String(x.corporationContactName).trim()) ? String(x.corporationContactName) : '（未設定）')
                    : '（個人のため不要）';
                addInfoRow('担当者名', corpContactText);

                if (x.companySiteUrl && String(x.companySiteUrl).trim()) {
                    const a = document.createElement('a');
                    a.className = 'link';
                    a.href = String(x.companySiteUrl);
                    a.target = '_blank';
                    a.rel = 'noopener noreferrer';
                    a.textContent = String(x.companySiteUrl);
                    addInfoRow('会社サイトURL', a);
                } else {
                    addInfoRow('会社サイトURL', '（未設定）');
                }

                dSkills.innerHTML = x.skills.length > 0 
                    ? x.skills.map(s => `<span class="tag">${s}</span>`).join('')
                    : '<span style="color: #586069;">（未設定）</span>';
                const dailyPart = ((x.hoursPerDay || x.daysPerWeek) ? ((x.hoursPerDay ? `${x.hoursPerDay}h/day` : '') + (x.hoursPerDay && x.daysPerWeek ? '・' : '') + (x.daysPerWeek ? `${x.daysPerWeek}day/week` : '')) : '');
                const weekLine = `週${x.workHours}`;
                const dailyLine = dailyPart;

                // サイドバー：メタ情報表示
                let parts = [];

                // フリー入力の働き方があれば表示（その下にメタを出す）
                if (x.workStyleText && x.workStyleText.toString().trim()) {
                    parts.push(`<div class="detail-title">働き方</div><div class="desc" id="dWorkStyle">${String(x.workStyleText).replace(/\n/g,'<br>')}</div>`);
                }

                // 希望単価 / 稼働 は「見出し → 下にテキスト」でシンプルに表示
                parts.push(`
                    <div class="detail-title">希望単価</div>
                    <div class="desc" title="${String(x.rateText ?? '').replaceAll('"','&quot;')}">${x.rateText || '未設定'}</div>
                `);

                parts.push(`
                    <div class="detail-title">稼働</div>
                    <div class="desc" title="${(weekLine + (dailyLine ? ' ' + dailyLine : '')).replaceAll('"','&quot;')}">
                        ${weekLine}${dailyLine ? '<br><span>' + dailyLine + '</span>' : ''}
                    </div>
                `);

                dMeta.innerHTML = parts.join('');
                
                if (x.portfolios && x.portfolios.length > 0) {
                    dPortfolio.innerHTML = x.portfolios.map(url =>
                        `<a class="link" href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`
                    ).join('<br>');
                } else {
                    dPortfolio.innerHTML = '<span style="color: #586069;">（未設定）</span>';
                }

                if (x.experienceCompanies && x.experienceCompanies.trim()) {
                    dExperienceCompanies.innerHTML = x.experienceCompanies.replace(/\n/g, '<br>');
                } else {
                    dExperienceCompanies.innerHTML = '<span style="color: #586069;">（未設定）</span>';
                }
                
                // スカウト済みかどうかでボタンの表示とリンクを変更
                if (x.threadId) {
                    // スカウト済みの場合
                    dScoutLink.textContent = 'スカウト済み';
                    dScoutLink.href = '<?php echo e(route("company.threads.show", ["thread" => ":threadId"])); ?>'.replace(':threadId', x.threadId);
                    dScoutLink.classList.remove('btn-primary');
                    dScoutLink.classList.add('btn-secondary');
                } else {
                    // スカウト未済の場合
                    dScoutLink.textContent = 'スカウト';
                    dScoutLink.href = '<?php echo e(route("company.scouts.create")); ?>?corporate_id=' + id;
                    dScoutLink.classList.remove('btn-secondary');
                    dScoutLink.classList.add('btn-primary');
                }
            };

            const selectCard = (card) => {
                list.querySelectorAll('.card').forEach((el) => {
                    el.classList.remove('is-selected');
                    el.setAttribute('aria-pressed', 'false');
                });
                card.classList.add('is-selected');
                card.setAttribute('aria-pressed', 'true');
                render(parseInt(card.getAttribute('data-id')));
                placeDetailPanel(card);
            };

            const isNarrowLayout = () => window.matchMedia('(max-width: 1200px)').matches;

            // 1200px以下: クリックしたカードの直下に「選択中」パネルを全幅で差し込む
            // 1201px以上: 右サイドバーに戻す
            const placeDetailPanel = (card) => {
                if (!detailPanel) return;

                if (!isNarrowLayout()) {
                    if (detailSidebarHost && detailPanel.parentElement !== detailSidebarHost) {
                        detailSidebarHost.appendChild(detailPanel);
                    }
                    return;
                }

                if (card && card.insertAdjacentElement) {
                    card.insertAdjacentElement('afterend', detailPanel);
                    // 画面外に出ている場合のみ、見える位置へ（過度なスクロールを避ける）
                    const rect = detailPanel.getBoundingClientRect();
                    if (rect.top > window.innerHeight || rect.bottom < 0) {
                        detailPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                    return;
                }

                // カードが無いケース（検索結果0件など）
                if (list && list.parentElement) {
                    list.parentElement.insertBefore(detailPanel, list);
                }
            };

            // 初期表示：最初のカードを選択
            const firstCard = list.querySelector('.card');
            if (firstCard) {
                selectCard(firstCard);
            } else {
                placeDetailPanel(null);
            }

            list.addEventListener('click', (e) => {
                // スカウトボタンがクリックされた場合はカード選択をしない
                if (e.target.closest('.card-scout-btn')) return;
                const card = e.target.closest('.card');
                if (!card) return;
                selectCard(card);
            });
            list.addEventListener('keydown', (e) => {
                if (e.key !== 'Enter' && e.key !== ' ') return;
                // スカウトボタンにフォーカスがある場合はカード選択をしない
                if (e.target.closest('.card-scout-btn')) return;
                const card = e.target.closest('.card');
                if (!card) return;
                e.preventDefault();
                selectCard(card);
            });

            // リサイズで 1200px を跨いだ場合に配置を戻す/差し込む
            let resizeTimer = null;
            window.addEventListener('resize', () => {
                window.clearTimeout(resizeTimer);
                resizeTimer = window.setTimeout(() => {
                    const selected = list.querySelector('.card.is-selected');
                    placeDetailPanel(selected);
                }, 50);
            });
        })();
    </script>
</body>
</html><?php /**PATH /var/www/resources/views/company/corporates/index.blade.php ENDPATH**/ ?>