<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>企業プロフィール登録 - AIプロマッチ</title>
    <style>
        /* リセット & ベース */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Hiragino Sans', 'Hiragino Kaku Gothic ProN', 'Yu Gothic', sans-serif;
            min-height: 100vh;
            position: relative;
            color: #0f172a;
        }

        /* 背景デザイン - 薄い青色ベース */
        .background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background:
                radial-gradient(ellipse at top left, rgba(219, 234, 254, 0.75) 0%, transparent 55%),
                radial-gradient(ellipse at bottom right, rgba(186, 230, 253, 0.55) 0%, transparent 55%),
                radial-gradient(ellipse at center, rgba(224, 242, 254, 0.45) 0%, transparent 70%),
                linear-gradient(135deg, #eff6ff 0%, #dbeafe 20%, #bae6fd 45%, #e0f2fe 70%, #f0f9ff 100%);
            overflow: hidden;
            z-index: 0;
        }

        /* コンテナ */
        .container {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding: 40px 20px;
        }

        /* カード */
        .register-card {
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(24px) saturate(180%);
            border-radius: 12px;
            padding: 40px 64px;
            width: 100%;
            max-width: 720px;
            box-shadow:
                0 25px 70px rgba(30, 136, 229, 0.18),
                0 10px 40px rgba(3, 169, 244, 0.10),
                0 0 100px rgba(255, 255, 255, 0.35),
                inset 0 1px 1px rgba(255, 255, 255, 1),
                inset 0 -1px 1px rgba(30, 136, 229, 0.08);
            position: relative;
            animation: cardFadeIn 0.6s ease-out, glow 5s ease-in-out infinite;
            border: 1px solid rgba(255, 255, 255, 0.7);
        }

        @keyframes cardFadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes glow {

            0%,
            100% {
                box-shadow:
                    0 25px 70px rgba(30, 136, 229, 0.18),
                    0 10px 40px rgba(3, 169, 244, 0.10),
                    0 0 100px rgba(255, 255, 255, 0.35),
                    inset 0 1px 1px rgba(255, 255, 255, 1),
                    inset 0 -1px 1px rgba(30, 136, 229, 0.08);
            }

            50% {
                box-shadow:
                    0 30px 80px rgba(30, 136, 229, 0.24),
                    0 15px 50px rgba(3, 169, 244, 0.16),
                    0 0 120px rgba(255, 255, 255, 0.45),
                    0 0 40px rgba(100, 181, 246, 0.16),
                    inset 0 1px 1px rgba(255, 255, 255, 1),
                    inset 0 -1px 1px rgba(30, 136, 229, 0.10);
            }
        }

        /* ロゴ */
        .logo {
            display: flex;
            align-items: baseline;
            justify-content: center;
            margin-bottom: 18px;
            gap: 10px;
        }

        .logo-text {
            font-weight: 900;
            font-size: 22px;
            letter-spacing: 0.5px;
            color: #0b1220;
        }

        .logo-badge {
            background: #0b1220;
            color: #fff;
            padding: 2px 10px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 800;
            font-style: italic;
        }

        .page-title {
            text-align: center;
            font-weight: 900;
            font-size: 18px;
            color: #0f172a;
            margin-bottom: 18px;
        }

        /* 成功/エラー */
        .success-box {
            background: rgba(16, 185, 129, 0.10);
            border: 1px solid rgba(16, 185, 129, 0.25);
            color: #065f46;
            padding: 12px 14px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 14px;
        }

        .error-box {
            background: rgba(239, 68, 68, 0.08);
            border: 1px solid rgba(239, 68, 68, 0.20);
            color: #7f1d1d;
            padding: 12px 14px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 14px;
        }

        /* フォーム */
        .register-form {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .two-col {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .form-group {
            position: relative;
        }

        .label {
            display: block;
            font-size: 13px;
            font-weight: 900;
            color: #334155;
            margin-bottom: 6px;
        }

        .form-input,
        .form-textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            transition: all 0.2s ease;
            background: #fff;
            outline: none;
        }

        .form-textarea {
            min-height: 120px;
            resize: vertical;
        }

        .form-input::placeholder,
        .form-textarea::placeholder {
            color: #bdbdbd;
        }

        .form-input:focus,
        .form-textarea:focus {
            border-color: #1e88e5;
            box-shadow: 0 0 0 3px rgba(30, 136, 229, 0.1);
        }

        .form-input.is-invalid,
        .form-textarea.is-invalid {
            border-color: rgba(239, 68, 68, 0.8);
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.10);
        }

        .error-message {
            display: block;
            margin-top: 6px;
            font-size: 13px;
            font-weight: 800;
            color: #dc2626;
        }

        .help {
            margin-top: 6px;
            font-size: 12px;
            font-weight: 800;
            color: #64748b;
        }

        /* ボタン */
        .btn-row {
            display: flex;
            gap: 12px;
            margin-top: 8px;
            flex-wrap: wrap;
        }

        .btn {
            flex: 1;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, #1e88e5 0%, #1976d2 100%);
            color: #fff;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(30, 136, 229, 0.25);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%);
            box-shadow: 0 6px 16px rgba(30, 136, 229, 0.32);
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: rgba(15, 23, 42, 0.08);
            color: #0f172a;
            font-size: 16px;
        }

        .btn-secondary:hover {
            background: rgba(15, 23, 42, 0.12);
            transform: translateY(-1px);
        }
        /* 代表者生年月日クリアボタンの最小幅を指定（create ページで縦表示になってしまう問題の対策） */
        #representativeBirthClearBtn {
            min-width: 80px;
        }

    </style>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <div class="background"></div>

    <div class="container px-4 md:px-6 lg:px-8 py-8 md:py-12">
        <div class="register-card w-full max-w-2xl bg-white/90 backdrop-blur-xl border border-white/70 rounded-xl p-6 md:p-10 lg:p-12 shadow-[0_25px_70px_rgba(30,136,229,0.18)]">
            <div class="page-title text-lg md:text-xl font-black text-center">企業プロフィール登録</div>
            @include('partials.error-panel')

            @if (session('success'))
            <div class="success-box">
                {{ session('success') }}
            </div>
            @endif

            @if (session('error'))
            <div class="error-box">
                {{ session('error') }}
            </div>
            @endif

            <form class="register-form" method="POST" action="{{ route('company.profile.store') }}">
                @csrf

                <div class="form-group">
                    <label class="label" for="company_name">企業名（必須）</label>
                    <input
                        id="company_name"
                        type="text"
                        name="company_name"
                        value="{{ old('company_name') }}"
                        class="form-input @error('company_name') is-invalid @enderror"
                        placeholder="例: 株式会社AITECH"
>
                    @error('company_name')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label class="label" for="company_name_kana">企業名カナ（任意）</label>
                    <input
                        id="company_name_kana"
                        type="text"
                        name="company_name_kana"
                        value="{{ old('company_name_kana') }}"
                        class="form-input @error('company_name_kana') is-invalid @enderror"
                        placeholder="例: カブシキガイシャエーアイテック"
>
                    @error('company_name_kana')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label class="label" for="overview">会社概要（任意）</label>
                    <textarea
                        id="overview"
                        name="overview"
                        class="form-textarea @error('overview') is-invalid @enderror"
                        placeholder="事業内容や特徴など（2000文字以内）">{{ old('overview') }}</textarea>
                    @error('overview')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="two-col grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="label" for="contact_name">担当者名（任意）</label>
                        <input
                            id="contact_name"
                            type="text"
                            name="contact_name"
                            value="{{ old('contact_name') }}"
                            class="form-input @error('contact_name') is-invalid @enderror"
                            placeholder="例: 山田 太郎">
                        @error('contact_name')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="department">部署（任意）</label>
                        <input
                            id="department"
                            type="text"
                            name="department"
                            value="{{ old('department') }}"
                            class="form-input @error('department') is-invalid @enderror"
                            placeholder="例: 開発部">
                        @error('department')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label class="label" for="introduction">自己紹介（任意）</label>
                    <textarea
                        id="introduction"
                        name="introduction"
                        class="form-textarea @error('introduction') is-invalid @enderror"
                        placeholder="フリーランスに伝えたいこと（募集背景/働き方など・2000文字以内）">{{ old('introduction') }}</textarea>
                    @error('introduction')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                    <div class="help">登録後は「プロフィール設定」から更新できます</div>
                </div>

                <div class="form-group">
                    <label class="label" for="email">メールアドレス（必須）</label>
                    <input
                        id="email"
                        type="email"
                        name="email"
                        value="{{ old('email') }}"
                        class="form-input @error('email') is-invalid @enderror"
                        placeholder="例: info@example.com"
>
                    @error('email')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label class="label" for="corporate_number">法人番号（必須）</label>
                    <input
                        id="corporate_number"
                        type="text"
                        name="corporate_number"
                        value="{{ old('corporate_number') }}"
                        class="form-input @error('corporate_number') is-invalid @enderror"
                        placeholder="例: 1234567890123（13桁）"
>
                    @error('corporate_number')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label class="label" for="representative_phone">代表電話番号（必須）</label>
                    <input
                        id="representative_phone"
                        type="text"
                        name="representative_phone"
                        value="{{ old('representative_phone') }}"
                        class="form-input @error('representative_phone') is-invalid @enderror"
                        placeholder="例: 03-1234-5678"
>
                    @error('representative_phone')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <div class="label">※本社所在地</div>
                </div>

                <div class="two-col grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="label" for="hq_postal_code">郵便番号（必須）</label>
                        <input
                            id="hq_postal_code"
                            type="text"
                            name="hq_postal_code"
                            value="{{ old('hq_postal_code') }}"
                            class="form-input @error('hq_postal_code') is-invalid @enderror"
                            placeholder="例: 100-0001"
>
                        @error('hq_postal_code')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="hq_prefecture">都道府県（必須）</label>
                        <input
                            id="hq_prefecture"
                            type="text"
                            name="hq_prefecture"
                            value="{{ old('hq_prefecture') }}"
                            class="form-input @error('hq_prefecture') is-invalid @enderror"
                            placeholder="例: 東京都"
>
                        @error('hq_prefecture')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="two-col grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="label" for="hq_city">市区町村（必須）</label>
                        <input
                            id="hq_city"
                            type="text"
                            name="hq_city"
                            value="{{ old('hq_city') }}"
                            class="form-input @error('hq_city') is-invalid @enderror"
                            placeholder="例: 千代田区"
>
                        @error('hq_city')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="hq_address">住所（必須）</label>
                        <input
                            id="hq_address"
                            type="text"
                            name="hq_address"
                            value="{{ old('hq_address') }}"
                            class="form-input @error('hq_address') is-invalid @enderror"
                            placeholder="例: 1-1-1（番地・建物名など）"
>
                        @error('hq_address')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <div class="label">※代表者</div>
                </div>

                <div class="two-col grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="label" for="representative_last_name">代表者名（姓 / 0-20文字）（必須）</label>
                        <input
                            id="representative_last_name"
                            type="text"
                            name="representative_last_name"
                            value="{{ old('representative_last_name') }}"
                            class="form-input @error('representative_last_name') is-invalid @enderror"
                            placeholder="例: 山田"
>
                        @error('representative_last_name')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="representative_first_name">代表者名（名 / 0-20文字）（必須）</label>
                        <input
                            id="representative_first_name"
                            type="text"
                            name="representative_first_name"
                            value="{{ old('representative_first_name') }}"
                            class="form-input @error('representative_first_name') is-invalid @enderror"
                            placeholder="例: 太郎"
>
                        @error('representative_first_name')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="two-col grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="label" for="representative_last_name_kana">代表者名カナ（セイ / 0-20文字）（必須）</label>
                        <input
                            id="representative_last_name_kana"
                            type="text"
                            name="representative_last_name_kana"
                            value="{{ old('representative_last_name_kana') }}"
                            class="form-input @error('representative_last_name_kana') is-invalid @enderror"
                            placeholder="例: ヤマダ"
>
                        @error('representative_last_name_kana')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="representative_first_name_kana">代表者名カナ（メイ / 0-20文字）（必須）</label>
                        <input
                            id="representative_first_name_kana"
                            type="text"
                            name="representative_first_name_kana"
                            value="{{ old('representative_first_name_kana') }}"
                            class="form-input @error('representative_first_name_kana') is-invalid @enderror"
                            placeholder="例: タロウ"
>
                        @error('representative_first_name_kana')
                        <span class="error-message">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label class="label">代表者の生年月日（任意）</label>
                    <div class="birthday-widget" aria-label="代表者の生年月日入力">
                        <div class="birthday-row birthday-row--single" style="display:flex;gap:8px;align-items:center;">
                            <select id="representativeBirthYear" class="form-input birthday-select" aria-label="年" style="width:34%;">
                                <option value="">年</option>
                            </select>
                            <select id="representativeBirthMonth" class="form-input birthday-select" aria-label="月" style="width:20%;">
                                <option value="">月</option>
                            </select>
                            <select id="representativeBirthDay" class="form-input birthday-select" aria-label="日" style="width:20%;">
                                <option value="">日</option>
                            </select>

                            <input
                                type="text"
                                id="representativeBirthText"
                                class="form-input birthday-text"
                                inputmode="numeric"
                                autocomplete="bday"
                                placeholder="YYYY/MM/DD（例: 1990/01/23）"
                                style="width:40%;">
                            <button type="button" class="btn btn-secondary" id="representativeBirthClearBtn" style="padding:8px 10px; font-weight:700; min: width 80%;">クリア</button>
                        </div>

                        <input
                            type="date"
                            name="representative_birthdate"
                            id="representativeBirthHidden"
                            class="form-input birthday-hidden @error('representative_birthdate') is-invalid @enderror"
                            value="{{ old('representative_birthdate') }}"
                            style="display:none;">

                        <div style="margin-top:6px; font-size:13px; font-weight:800; color:#64748b;">プルダウンまたは手入力（YYYY/MM/DD）で入力できます。</div>
                    </div>
                    @error('representative_birthdate')
                    <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="btn-row flex flex-col md:flex-row gap-3">
                    <a class="btn btn-secondary w-full md:flex-1" href="{{ url()->previous() }}">戻る</a>
                    <button class="btn btn-primary w-full md:flex-1" type="submit">登録</button>
                </div>
            </form>
        </div>
    </div>
</body>

<script>
    (function () {
        const hiddenInput = document.getElementById('representativeBirthHidden');
        const yearSelect = document.getElementById('representativeBirthYear');
        const monthSelect = document.getElementById('representativeBirthMonth');
        const daySelect = document.getElementById('representativeBirthDay');
        const textInput = document.getElementById('representativeBirthText');
        const clearBtn = document.getElementById('representativeBirthClearBtn');
        if (!hiddenInput || !yearSelect || !monthSelect || !daySelect || !textInput || !clearBtn) return;

        const pad2 = (n) => String(n).padStart(2, '0');
        const isValidDate = (y, m, d) => {
            const dt = new Date(y, m - 1, d);
            return dt.getFullYear() === y && (dt.getMonth() + 1) === m && dt.getDate() === d;
        };
        const lastDayOfMonth = (y, m) => new Date(y, m, 0).getDate();

        const fillYears = () => {
            const currentYear = new Date().getFullYear();
            const maxYear = currentYear - 10;
            const minYear = currentYear - 100;
            for (let y = maxYear; y >= minYear; y--) {
                const opt = document.createElement('option');
                opt.value = String(y);
                opt.textContent = String(y);
                yearSelect.appendChild(opt);
            }
        };

        const fillMonths = () => {
            for (let m = 1; m <= 12; m++) {
                const opt = document.createElement('option');
                opt.value = String(m);
                opt.textContent = String(m);
                monthSelect.appendChild(opt);
            }
        };

        const fillDays = (y, m, selectedDay = '') => {
            const placeholder = daySelect.querySelector('option[value=""]');
            daySelect.innerHTML = '';
            if (placeholder) daySelect.appendChild(placeholder);
            if (!y || !m) return;

            const max = lastDayOfMonth(y, m);
            for (let d = 1; d <= max; d++) {
                const opt = document.createElement('option');
                opt.value = String(d);
                opt.textContent = String(d);
                daySelect.appendChild(opt);
            }
            if (selectedDay) daySelect.value = selectedDay;
        };

        const syncToHidden = () => {
            const y = parseInt(yearSelect.value, 10);
            const m = parseInt(monthSelect.value, 10);
            const d = parseInt(daySelect.value, 10);
            if (!y || !m || !d || !isValidDate(y, m, d)) {
                hiddenInput.value = '';
                return;
            }
            hiddenInput.value = `${y}-${pad2(m)}-${pad2(d)}`;
        };

        const syncText = () => {
            const y = parseInt(yearSelect.value, 10);
            const m = parseInt(monthSelect.value, 10);
            const d = parseInt(daySelect.value, 10);
            if (!y || !m || !d || !isValidDate(y, m, d)) {
                textInput.value = '';
                return;
            }
            textInput.value = `${y}/${pad2(m)}/${pad2(d)}`;
        };

        const setFromISO = (iso) => {
            const match = (iso || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
            if (!match) return;
            const y = parseInt(match[1], 10);
            const m = parseInt(match[2], 10);
            const d = parseInt(match[3], 10);
            if (!isValidDate(y, m, d)) return;
            yearSelect.value = String(y);
            monthSelect.value = String(m);
            fillDays(y, m, String(d));
            daySelect.value = String(d);
            syncText();
        };

        const parseTextToISO = (txt) => {
            const raw = (txt || '').trim();
            if (!raw) return '';
            const match = raw.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
            if (!match) return '';
            const y = parseInt(match[1], 10);
            const m = parseInt(match[2], 10);
            const d = parseInt(match[3], 10);
            if (!isValidDate(y, m, d)) return '';
            return `${y}-${pad2(m)}-${pad2(d)}`;
        };

        fillYears();
        fillMonths();
        if (hiddenInput.value) {
            const normalized = hiddenInput.value.match(/^\d{4}-\d{2}-\d{2}$/)
                ? hiddenInput.value
                : parseTextToISO(hiddenInput.value);
            if (normalized) {
                hiddenInput.value = normalized;
                setFromISO(normalized);
            }
        }

        yearSelect.addEventListener('change', () => {
            const y = parseInt(yearSelect.value, 10);
            const m = parseInt(monthSelect.value, 10);
            const currentDay = daySelect.value;
            fillDays(y || 0, m || 0, currentDay);
            syncToHidden();
            syncText();
        });
        monthSelect.addEventListener('change', () => {
            const y = parseInt(yearSelect.value, 10);
            const m = parseInt(monthSelect.value, 10);
            const currentDay = daySelect.value;
            fillDays(y || 0, m || 0, currentDay);
            syncToHidden();
            syncText();
        });
        daySelect.addEventListener('change', () => {
            syncToHidden();
            syncText();
        });

        textInput.addEventListener('blur', () => {
            const iso = parseTextToISO(textInput.value);
            if (!iso) return;
            hiddenInput.value = iso;
            setFromISO(iso);
        });

        clearBtn.addEventListener('click', () => {
            yearSelect.value = '';
            monthSelect.value = '';
            daySelect.value = '';
            textInput.value = '';
            hiddenInput.value = '';
            fillDays(0, 0);
        });
    })();
</script>

</html>
