<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Thread extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'freelancer_id',
        'job_id',
        'latest_sender_type',
        'latest_sender_id',
        'latest_message_at',
        'is_unread_for_company',
        'is_unread_for_freelancer',
    ];

    protected $casts = [
        'job_id' => 'integer',
        'latest_sender_id' => 'integer',
        'latest_message_at' => 'datetime',
        'is_unread_for_company' => 'boolean',
        'is_unread_for_freelancer' => 'boolean',
    ];

    /**
     * こ�EスレチE��に参加してぁE��企業惁E��を取征E     * 使用場面: スレチE��一覧画面で企業名を表示する際など
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * こ�EスレチE��に参加してぁE��フリーランサー惁E��を取征E     * 使用場面: スレチE��一覧画面でフリーランサー名を表示する際など
     */
    public function freelancer(): BelongsTo
    {
        return $this->belongsTo(Freelancer::class);
    }

    /**
     * こ�EスレチE��に関連する求人惁E��を取得（任意！E     * 使用場面: 求人に関連するメチE��ージかどぁE��を判定する際など
     */
    public function job(): BelongsTo
    {
        return $this->belongsTo(Job::class);
    }

    /**
     * こ�EスレチE��冁E�EメチE��ージ一覧を取得（送信日時頁E��E     * 使用場面: メチE��ージ詳細画面で会話履歴を表示する際など
     */
    public function messages(): HasMany
    {
        return $this->hasMany(Message::class)->orderBy('sent_at');
    }
}